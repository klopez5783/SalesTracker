package com.example.hw4


import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface SaleDAO {
    @Insert
    fun insertSale(sale: Sale)

    @Insert
    fun insertSale(saleList: List<Sale>)

    @Query("Select * from sale")
    fun getAllSales(): List<Sale>

    @Query("Delete from sale")
    fun deleteAllSales()
}