package com.example.hw4

import android.app.Application
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.google.firebase.auth.FirebaseAuth

@Composable
fun loginScreen(navController: NavHostController){

    val viewModel = viewModel {
        LoginScreenViewModal()
    }

    val context = LocalContext.current

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(15.dp)
    ){
        Surface(
            modifier = Modifier
                .width(400.dp)
                .padding(1.dp)
                .shadow(
                    elevation = 15.dp,
                    shape = RoundedCornerShape(20.dp)
                ),/*Padding for surface*/
            shape = RoundedCornerShape(20.dp)
        ) {
            Column {
                Text(text = "Login", Modifier.padding(15.dp), fontSize = 30.sp)
                TextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth()
                )
                TextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth()
                )
                Button(
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth(),
                    onClick = {
                        // Create an instance of LoginFirebaseViewModel with required parameters
                        viewModel.loginFirebase(
                            email = email,
                            password = password,
                            successfulLoginHandler = {
                                // Handle successful login (e.g., navigate to the sales list screen)
                                navController.navigate("homeScreen")
                            },
                            unsuccessfulLoginHandler = {error ->
                                // Handle unsuccessful login (e.g., display a message to the user)
                                Toast.makeText(context, "Login unsuccessful", Toast.LENGTH_SHORT).show()
                                Log.d("LoginError",error)
                            }
                        )
                    }
                ) {
                    Text(text = "Login")
                }


            }
        }

    }
}

