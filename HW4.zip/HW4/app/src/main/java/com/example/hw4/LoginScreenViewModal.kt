package com.example.hw4

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class LoginScreenViewModal : ViewModel() {
    fun loginFirebase(
        email: String,
        password: String,
        successfulLoginHandler: () -> Unit,
        unsuccessfulLoginHandler: (String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password).await()
                withContext(Dispatchers.Main) {
                    successfulLoginHandler()
                }
            } catch (e: Exception) {
                val errorMessage = e.message ?: "Unknown error" // Get the error message or use a default message
                withContext(Dispatchers.Main) {
                    unsuccessfulLoginHandler(errorMessage)
                }
            }
        }
    }

    fun performLogout(): Boolean {
        var success = false
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val firebaseAuth = FirebaseAuth.getInstance()
                val currentUser = firebaseAuth.currentUser
                val email = currentUser!!.email
                Log.d("Logout" , "User Logged in: $currentUser \n email : $email")
                Log.d("Logout", "Attempting sign out...")
                FirebaseAuth.getInstance().signOut()
                Log.d("Logout", "Sign out successful.")
                success = true;
            } catch (e: Exception) {
                val errorMessage = e.message ?: "Unknown error" // Get the error message or use a default message
                Log.e("Logout", "Error during sign out: $errorMessage")
                withContext(Dispatchers.Main) {
                    // Call unsuccessful logout handler with the error message
                    Log.d("Logout",errorMessage)
                }
            }
            Log.d("Logout", "Success value: $success")
        }
        return success
    }




}