package com.example.hw4

import android.app.Application
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class HomeViewModel( private val repository: SaleRepository) : ViewModel() {


    var list by mutableStateOf<List<Sale>>(emptyList())


    init {
        fillDBWithData()
        fetchDataForHomeScreen()
    }

    private fun fetchDataForHomeScreen() {
        viewModelScope.launch {
            try {
                val tempList = repository.getAllSales()
                list = tempList ?: emptyList()
            } catch (e: Exception) {
                // Handle error
                Log.e("FetchDataError", "Error fetching data: $e")
            }
        }
    }


    private fun fillDBWithData() {


        val list: List<Sale> = mutableListOf(
            Sale("Car", 10.54),
            Sale("Bike", 20.99),
            Sale("Book", 15.75),
            Sale("Phone", 200.0),
            Sale("Laptop", 500.0),
            Sale("Chair", 30.0)
        )


        runBlocking {
            launch(Dispatchers.IO) {
                val tempList = repository.getAllSales()
                if (tempList?.isEmpty() == true) {
                    repository.deleteAllSales()
                    for (x in list) {
                        Log.d("DB_Fill", "inside fillDBWithData : Current Item in list : $x.name")
                        repository.insertSale(x)
                    }
                }
            }

        }

    }
}