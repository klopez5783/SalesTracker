package com.example.hw4

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class AddViewModel( private val repository: SaleRepository) : ViewModel() {
    var list by mutableStateOf<List<Sale>>(emptyList())
    fun insertSale(sale : Sale){

        runBlocking {
            viewModelScope.launch (Dispatchers.IO) {
                try {
                    Log.d("InsertSale","Inside Sale Function sale : $sale")
                    repository.insertSale(sale)
                }catch (e:Exception){
                    Log.d("InsertSale","Error : $e")
                }
            }
        }
    }

}