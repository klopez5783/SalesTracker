package com.example.hw4


import android.app.Application
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavController
import androidx.navigation.NavHost
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.firebase.auth.FirebaseAuth

@Composable
fun rootScreen(navController: NavHostController,application : Application){

    var selectedItemIndex by rememberSaveable { mutableStateOf(0) }


    val context = LocalContext.current

    val navItemsList = listOf(
        NavBar(
            title="Home",
            iconSelected = Icons.Filled.Home,
            iconUnselected = Icons.Outlined.Home,
            route="homeScreen"
        ),
        NavBar(title="Add",
            iconSelected = Icons.Filled.Add,
            iconUnselected = Icons.Outlined.Add,
            route="AddScreen"
        ),
    )
    val firebaseAuth = FirebaseAuth.getInstance()
    val currentUser = firebaseAuth.currentUser

    // Check if currentUser is not null to determine if the user is logged in
    var isLoggedIn = false

    // You can use isLoggedIn to determine whether to show the navigation bar
    var showNavigationBar by rememberSaveable { mutableStateOf(isLoggedIn) }


    Scaffold(
        bottomBar = {
            if(showNavigationBar){
                NavigationBar {
                    navItemsList.forEachIndexed { index, item ->
                        NavigationBarItem(

                            selected = (selectedItemIndex == index),
                            onClick = {
                                Log.d("Inside Navigation Click","$item")
                                selectedItemIndex = index
                                Toast.makeText(context,item.title, Toast.LENGTH_SHORT).show()
                                navController.navigate(item.route)
                            },
                            label = { Text(text = item.title) },
                            icon = {
                                Icon(
                                    contentDescription = item.title,
                                    imageVector =
                                    if (index == selectedItemIndex) item.iconSelected
                                    else item.iconUnselected
                                )
                            }

                        )
                    }
                }
            }
        }
    ) {
            padding ->
        Column(
            modifier = Modifier.padding(padding)
        ) {
            NavHost(navController = navController, startDestination = "loginScreen") {
                composable(route = "homeScreen") {
                    isLoggedIn = true
                    LaunchedEffect(isLoggedIn) {
                        showNavigationBar = isLoggedIn
                    }
                    HomeScreen(navController)
                }
                composable(route = "loginScreen") {
                    isLoggedIn = false
                    LaunchedEffect(isLoggedIn) {
                        showNavigationBar = isLoggedIn
                    }
                    loginScreen(navController)
                }
                composable(route = "AddScreen") {
                    AddScreen(navController)
                }
            }
        }
    }

}


