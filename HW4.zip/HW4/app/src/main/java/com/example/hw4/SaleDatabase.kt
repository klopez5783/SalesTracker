package com.example.hw4


import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Sale::class], version = 1, exportSchema = false)
abstract class SaleDatabase : RoomDatabase() {
    abstract fun saleDAO(): SaleDAO?
}

