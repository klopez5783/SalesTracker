package com.example.hw4


import android.app.Application
import android.util.Log
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

class SaleApplication : Application() {

    companion object{
        lateinit var repository: SaleRepository
    }

    override fun onCreate() {
        super.onCreate()

        runBlocking{
            launch(Dispatchers.IO) {
                // Create and return an instance of SaleDatabase
                val database = Room.databaseBuilder(
                    applicationContext,
                    SaleDatabase::class.java,
                    "Sale"
                ).build()
                repository = SaleRepository(database)
            }
        }
    }

    private suspend fun createDatabase(): SaleDatabase {
        return withContext(Dispatchers.IO) {
            // Simulated delay for database creation
            Log.d("CreateDatabase","Inside on create database")
            //delay(1000)

            // Create and return an instance of SaleDatabase
            Room.databaseBuilder(
                applicationContext,
                SaleDatabase::class.java,
                "Sale"
            ).build()
        }
    }

}