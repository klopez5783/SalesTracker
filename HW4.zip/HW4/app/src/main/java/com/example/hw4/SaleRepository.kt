package com.example.hw4

import android.util.Log
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SaleRepository(private val database: SaleDatabase) {

    suspend fun insertSale(sale : Sale) {
        Log.d("InsertSale","Inside Repository Function\nSale : $sale \n\n ")
        withContext(Dispatchers.IO) {
            database.saleDAO()?.insertSale(sale)
        }
    }

    // Function to get all sales from the database
    suspend fun getAllSales(): List<Sale>? {
        return withContext(Dispatchers.IO) {
            database.saleDAO()?.getAllSales()
        }
    }

    suspend fun deleteAllSales(){
        return withContext(Dispatchers.IO) {
            database.saleDAO()?.deleteAllSales()
        }
    }
}