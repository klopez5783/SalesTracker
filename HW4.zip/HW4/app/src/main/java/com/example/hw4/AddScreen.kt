package com.example.hw4

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

@Composable
fun AddScreen(navController: NavHostController) {

    val viewModel = viewModel {
        AddViewModel(SaleApplication.repository)
    }
    val context = LocalContext.current

    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("")}

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(15.dp)
    ){
        Surface(
            modifier = Modifier
                .width(400.dp)
                .padding(1.dp)
                .shadow(
                    elevation = 15.dp,
                    shape = RoundedCornerShape(20.dp)
                ),/*Padding for surface*/
            shape = RoundedCornerShape(20.dp)
        ) {
            Column {
                Text(text = "Add Sale", Modifier.padding(15.dp), fontSize = 30.sp)
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth()
                )
                TextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("Amount") },
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth()
                )
                Button(
                    modifier = Modifier
                        .padding(4.dp)
                        .fillMaxWidth(),
                    onClick = {
                        Log.d("ButtonClicked", "Button Click!!")
                        Log.d("InsertSale","Current List : ${viewModel.list}\n\n")
                        val Sale = Sale(name,amount.toDouble())
                        viewModel.insertSale(Sale)
                        Toast.makeText(context,"Sale : ${Sale.name} Has been Added",Toast.LENGTH_LONG).show()
                    }
                ) {
                    Text(text = "Add")
                }


            }
        }

    }

}