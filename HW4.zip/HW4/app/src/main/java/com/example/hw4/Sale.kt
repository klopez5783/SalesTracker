package com.example.hw4


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName="Sale")
data class Sale(
    @PrimaryKey val name:String = "NAME EMPTY",
    val amount: Double= 0.0
)
